n=3;
roll_no=22126040;
matrix=[roll_no * ones(1,n);randi(100,n-1,n)];
disp(matrix);
determinant=det(matrix);
disp("determinant:");
disp(determinant);
R=40;
n=50;
x=linspace(1,10,n);
y=R*x +randn(1,n)*5;
%plotting the data 
figure;
scatter(x,y,"filled");
hold on;
p=polyfit(x,y,1);
y_fit=polyval(p,x);
plot(x,y_fit,'-r','LineWidth',2);
xlabel('x');
ylabel('y');
title('Data points and Ploynomial Fit');
legend('Data points','Polynoial Fit');
grid on;
a=[4,6,8];
b=[5,6,3];
dot_product=dot(a,b);
cross_product=cross(a,b);
disp("display the dot product:");
disp(dot_product);
disp("display the cross product:");
disp(cross_product);
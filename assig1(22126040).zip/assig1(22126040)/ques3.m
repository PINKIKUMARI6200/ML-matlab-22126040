n=input("enter the value of n:");
roll_no=22126040;
matrix=[roll_no * ones(1,n);randi(100,n-1,n)];
disp(matrix);
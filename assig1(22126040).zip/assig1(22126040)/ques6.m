clear all
clc
R=5; %radius of circle
theta=linspace(0,2*pi,100);
x=R*cos(theta);
y=R*sin(theta);
plot(x,y);
title("Pinkikumari-2D Circle");
xlabel("x");
ylabel("y");
axis equal;
grid on;


R=40;
M=03;
W=29;
coefficients=[R,R*M,W,25];
root_of_polynomial=roots(coefficients);
disp('rooot of polynomials are:');
disp(root_of_polynomial);
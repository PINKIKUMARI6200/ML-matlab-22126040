clear all
close all
clc
%load the grayscale image dimensions
fig3=imread('fig3.png');
[rows,cols]=size(fig3);

load('gray_pixels.mat','gray_pixels');

fig4=reshape(gray_pixels,[rows,cols]);
imwrite(fig4,'fig4.png');

figure;
imshow(fig4);
title('Gray scale image from 1D array (fig4)');
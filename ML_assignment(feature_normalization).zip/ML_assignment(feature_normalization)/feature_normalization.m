% Load data from CSV
data = readtable('MentalHealthSurvey.csv');

% Extract numeric column (ratingScore)
AcademicWork = data.academic_workload;

% Handle NaN values (optional)
AcademicWork = rmmissing(AcademicWork); % Remove NaNs
% If you prefer imputation, you could use:
% AcademicWork(isnan(AcademicWork)) = mean(AcademicWork, 'omitnan');

% Min-Max scaling
minVal = min(AcademicWork);
maxVal = max(AcademicWork);
scaled = (AcademicWork - minVal) / (maxVal - minVal);

% Add back the scaled rating to the original data
data.scaled_AcademicWork = NaN(height(data), 1); % Initialize with NaNs
data.scaled_AcademicWork(~isnan(data.academic_workload)) = scaled;

% Save the result to a new file
writetable(data, 'MentalHealthSurvey_scaled.csv');
